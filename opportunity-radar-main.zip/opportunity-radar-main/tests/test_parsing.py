from datetime import timezone

from opportunity_radar.models import RawEvent
from opportunity_radar.normalize import detect_event_type, normalize_event
from opportunity_radar.utils import extract_magnitude, parse_datetime_safe


class FakeLLM:
    def classify_event(self, text: str):
        return "GUIDANCE_DOWNGRADE", 0.8

    def classify_sentiment(self, text: str):
        return "negative", 0.9

    def phrase_explanation(self, facts):
        return None


def test_extract_magnitude_percent() -> None:
    assert extract_magnitude("Promoter bought 2.3% stake") == 2.3


def test_detect_event_type_from_keywords() -> None:
    text = "Company reports earnings beat with strong margin expansion"
    assert detect_event_type(text) == "EARNINGS_BEAT"


def test_normalize_event_deterministic() -> None:
    event = RawEvent(
        source="SEBI_INSIDER",
        source_event_id="x1",
        stock_id="NSE:ABC",
        stock_symbol="ABC",
        published_at=parse_datetime_safe("2026-03-26"),
        title="Insider buy disclosure",
        text="Promoter insider buy 1.2% stake",
        payload={},
    )
    structured = normalize_event(event, FakeLLM())

    assert structured is not None
    assert structured.event_type == "INSIDER_BUY"
    assert structured.sentiment == "positive"
    assert structured.magnitude == 1.2
    assert structured.timestamp.tzinfo == timezone.utc


def test_normalize_event_llm_fallback() -> None:
    event = RawEvent(
        source="BSE_ANNOUNCEMENT",
        source_event_id="x2",
        stock_id="BSE:XYZ",
        stock_symbol="XYZ",
        published_at=parse_datetime_safe("2026-03-26"),
        title="Board update",
        text="Outlook revised lower for next quarter",
        payload={},
    )
    structured = normalize_event(event, FakeLLM())

    assert structured is not None
    assert structured.event_type == "GUIDANCE_DOWNGRADE"
    assert structured.sentiment == "negative"
    assert structured.confidence >= 0.8
