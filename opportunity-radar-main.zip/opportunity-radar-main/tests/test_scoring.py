from opportunity_radar.models import Signal
from opportunity_radar.scoring import compute_stock_score, rank_stocks
from opportunity_radar.utils import parse_datetime_safe


def _signal(
    stock_id: str,
    stock_symbol: str,
    signal_type: str,
    category: str,
    strength: float,
    event_date: str,
    confidence: float = 0.9,
    magnitude: float = 2.0,
) -> Signal:
    return Signal(
        stock_id=stock_id,
        stock_symbol=stock_symbol,
        signal_type=signal_type,
        category=category,
        strength=strength,
        confidence=confidence,
        explanation="test",
        event_ts=parse_datetime_safe(event_date),
        magnitude=magnitude,
    )


def test_compute_stock_score_neutral_without_signals() -> None:
    run_date = parse_datetime_safe("2026-03-27")
    result = compute_stock_score(
        stock_id="NSE:ZZZ",
        stock_symbol="ZZZ",
        signals=[],
        run_date=run_date,
    )

    assert result.final_score == 50
    assert result.raw_score == 50


def test_compute_stock_score_positive_alignment() -> None:
    run_date = parse_datetime_safe("2026-03-27")
    signals = [
        _signal("NSE:AAA", "AAA", "INSIDER_BUY", "insider", 25, "2026-03-27"),
        _signal("NSE:AAA", "AAA", "EARNINGS_BEAT", "earnings", 20, "2026-03-27"),
        _signal(
            "NSE:AAA",
            "AAA",
            "MANAGEMENT_SENTIMENT_SHIFT",
            "sentiment",
            15,
            "2026-03-26",
        ),
    ]
    result = compute_stock_score(
        stock_id="NSE:AAA",
        stock_symbol="AAA",
        signals=signals,
        run_date=run_date,
    )

    assert result.raw_score > 50
    assert result.confidence_multiplier > 1
    assert result.final_score > result.raw_score


def test_rank_stocks_orders_descending() -> None:
    run_date = parse_datetime_safe("2026-03-27")
    stocks = [
        {"stock_id": "NSE:AAA", "symbol": "AAA"},
        {"stock_id": "NSE:BBB", "symbol": "BBB"},
    ]
    signals = [
        _signal("NSE:AAA", "AAA", "INSIDER_BUY", "insider", 25, "2026-03-27"),
    ]
    ranked = rank_stocks(stocks, signals, run_date)

    assert ranked[0].stock_id == "NSE:AAA"
    assert ranked[0].rank == 1
    assert ranked[1].stock_id == "NSE:BBB"
    assert ranked[1].rank == 2
