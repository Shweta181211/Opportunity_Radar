from opportunity_radar.models import StructuredEvent
from opportunity_radar.signals import signal_from_event
from opportunity_radar.utils import parse_datetime_safe


def test_insider_buy_signal_strength_strong() -> None:
    event = StructuredEvent(
        source="SEBI_INSIDER",
        source_event_id="e1",
        stock_id="NSE:AAA",
        stock_symbol="AAA",
        event_type="INSIDER_BUY",
        magnitude=2.1,
        sentiment="positive",
        confidence=0.9,
        timestamp=parse_datetime_safe("2026-03-27"),
        raw_text="Promoter buy 2.1%",
    )
    signal = signal_from_event(event)

    assert signal is not None
    assert signal.category == "insider"
    assert signal.strength == 25


def test_management_sentiment_mild_positive() -> None:
    event = StructuredEvent(
        source="BSE_ANNOUNCEMENT",
        source_event_id="e2",
        stock_id="BSE:BBB",
        stock_symbol="BBB",
        event_type="MANAGEMENT_SENTIMENT_SHIFT",
        magnitude=0.8,
        sentiment="positive",
        confidence=0.7,
        timestamp=parse_datetime_safe("2026-03-27"),
        raw_text="Management outlook improved",
    )
    signal = signal_from_event(event)

    assert signal is not None
    assert signal.category == "sentiment"
    assert signal.strength == 5
