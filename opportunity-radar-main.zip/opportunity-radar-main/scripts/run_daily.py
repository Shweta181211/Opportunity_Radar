from __future__ import annotations

import sys
from pathlib import Path

# Ensure package imports resolve when executed as: python scripts/run_daily.py
ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from opportunity_radar.pipeline import run_daily_pipeline


if __name__ == "__main__":
    try:
        summary = run_daily_pipeline()
        print(summary)
    except RuntimeError as error:
        print(f"Pipeline failed: {error}")
        raise SystemExit(1)
