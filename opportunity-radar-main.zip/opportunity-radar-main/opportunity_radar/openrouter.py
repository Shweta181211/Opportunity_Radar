from __future__ import annotations

import json
import re
from typing import Any

import requests

from opportunity_radar.config import Settings
from opportunity_radar.models import EVENT_TYPES, SENTIMENTS
from opportunity_radar.utils import clamp


JSON_BLOCK_PATTERN = re.compile(r"\{.*\}", flags=re.DOTALL)


class OpenRouterClient:
    def __init__(self, settings: Settings):
        self.settings = settings

    @property
    def enabled(self) -> bool:
        if self.settings.fast_mode and self.settings.disable_openrouter_in_fast_mode:
            return False
        return bool(self.settings.openrouter_api_key)

    def _chat_json(self, system_prompt: str, user_prompt: str) -> dict[str, Any] | None:
        if not self.enabled:
            return None

        payload = {
            "model": self.settings.openrouter_model,
            "temperature": 0,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "response_format": {"type": "json_object"},
        }
        headers = {
            "Authorization": f"Bearer {self.settings.openrouter_api_key}",
            "Content-Type": "application/json",
        }

        try:
            response = requests.post(
                f"{self.settings.openrouter_api_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=self.settings.request_timeout_seconds,
            )
            response.raise_for_status()
            content = response.json()["choices"][0]["message"]["content"]
            return self._extract_json(content)
        except Exception:
            return None

    def _chat_text(self, system_prompt: str, user_prompt: str) -> str | None:
        if not self.enabled:
            return None

        payload = {
            "model": self.settings.openrouter_model,
            "temperature": 0.4,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
        }
        headers = {
            "Authorization": f"Bearer {self.settings.openrouter_api_key}",
            "Content-Type": "application/json",
        }

        try:
            response = requests.post(
                f"{self.settings.openrouter_api_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=self.settings.request_timeout_seconds,
            )
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except requests.exceptions.HTTPError as e:
            try:
                err_data = e.response.json()
                if "error" in err_data and "message" in err_data["error"]:
                    return f"🔌 API Error: {err_data['error']['message']}"
            except Exception:
                pass
            
            if e.response.status_code == 401:
                return "🔌 API Error: Unauthorized access. Please check your OPENROUTER_API_KEY in the .env file."
            elif e.response.status_code == 404:
                return f"🔌 API Error: The model '{self.settings.openrouter_model}' was not found or is blocked by your settings."
            return f"🔌 API Error: {e.response.text}"
        except Exception as e:
            print("Chat error:", e)
            return f"🔌 Connection Error: {str(e)}"

    @staticmethod
    def _extract_json(text: str) -> dict[str, Any] | None:
        if not text:
            return None
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        match = JSON_BLOCK_PATTERN.search(text)
        if not match:
            return None
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            return None

    def classify_event(self, text: str) -> tuple[str | None, float]:
        result = self._chat_json(
            "Classify financial event text. Return JSON only.",
            (
                "Allowed event_type: "
                "INSIDER_BUY, INSIDER_SELL, BULK_DEAL, EARNINGS_BEAT, EARNINGS_MISS, "
                "GUIDANCE_UPGRADE, GUIDANCE_DOWNGRADE, MANAGEMENT_SENTIMENT_SHIFT, REGULATORY_EVENT. "
                "Return {\"event_type\": string, \"confidence\": number}.\n"
                f"Text: {text}"
            ),
        )
        if not result:
            return None, 0.0

        event_type = str(result.get("event_type", "")).strip().upper()
        confidence = clamp(float(result.get("confidence", 0.5)), 0.0, 1.0)
        if event_type not in EVENT_TYPES:
            return None, 0.0
        return event_type, confidence

    def classify_sentiment(self, text: str) -> tuple[str | None, float]:
        result = self._chat_json(
            "Classify sentiment for financial event. Return JSON only.",
            (
                "Allowed sentiment: positive, neutral, negative. "
                "Return {\"sentiment\": string, \"confidence\": number}.\n"
                f"Text: {text}"
            ),
        )
        if not result:
            return None, 0.0

        sentiment = str(result.get("sentiment", "")).strip().lower()
        confidence = clamp(float(result.get("confidence", 0.5)), 0.0, 1.0)
        if sentiment not in SENTIMENTS:
            return None, 0.0
        return sentiment, confidence

    def phrase_explanation(self, facts: list[str]) -> str | None:
        result = self._chat_json(
            "Rewrite concise financial rationale using only the supplied facts.",
            (
                "Write 1-3 lines in plain English. Do not add facts not present below. "
                "Return {\"explanation\": string}. Facts:\n- "
                + "\n- ".join(facts)
            ),
        )
        if not result:
            return None
        explanation = str(result.get("explanation", "")).strip()
        return explanation or None

    def answer_user_query(self, question: str, facts: list[str]) -> str | None:
        prompt_facts = "\n- ".join(facts) if facts else "No data."
        return self._chat_text(
            "You are a financial signal assistant for Opportunity Radar, a tool that hunts for Alpha Signals. "
            "An Alpha Signal is a 'Deep Convergence' where multiple strong institutional triggers "
            "(e.g., Insider Buying, Earnings Beat, Bulk Deals) happen simultaneously for a single stock.",
            f"Answer the user query clearly in 4-8 lines. Use the latest market facts below if relevant.\n\n"
            f"Facts:\n- {prompt_facts}\n\n"
            f"User query: {question}"
        )
