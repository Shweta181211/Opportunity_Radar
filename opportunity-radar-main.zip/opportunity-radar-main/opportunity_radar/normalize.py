from __future__ import annotations

import re
from typing import Iterable

from opportunity_radar.models import RawEvent, StructuredEvent
from opportunity_radar.openrouter import OpenRouterClient
from opportunity_radar.utils import extract_magnitude


KEYWORD_RULES = [
    ("INSIDER_BUY", ["insider", "buy"]),
    ("INSIDER_SELL", ["insider", "sell"]),
    ("EARNINGS_BEAT", ["earnings", "beat"]),
    ("EARNINGS_MISS", ["earnings", "miss"]),
    ("GUIDANCE_UPGRADE", ["guidance", "upgrade"]),
    ("GUIDANCE_DOWNGRADE", ["guidance", "downgrade"]),
    ("MANAGEMENT_SENTIMENT_SHIFT", ["management", "outlook"]),
    ("REGULATORY_EVENT", ["regulatory", "notice"]),
]

POSITIVE_HINTS = ("buy", "beat", "upgrade", "strong", "approved", "growth")
NEGATIVE_HINTS = ("sell", "miss", "downgrade", "weak", "penalty", "default")
NUMBER_CLEANUP = re.compile(r"\s+")

POSITIVE_REGULATORY_HINTS = (
    "approval",
    "approved",
    "allotment",
    "award",
    "order",
    "amalgamation",
    "merger",
    "acquisition",
    "investment",
    "contract",
    "expansion",
)

NEGATIVE_REGULATORY_HINTS = (
    "penalty",
    "default",
    "investigation",
    "non-compliance",
    "violation",
    "fraud",
    "loss",
    "delay",
)


def _normalize_text(text: str) -> str:
    return NUMBER_CLEANUP.sub(" ", text.strip().lower())


def detect_event_type(text: str) -> str | None:
    candidate = _normalize_text(text)

    if "bulk" in candidate and "deal" in candidate:
        return "BULK_DEAL"

    for event_type, tokens in KEYWORD_RULES:
        if all(token in candidate for token in tokens):
            return event_type

    if any(token in candidate for token in ("open offer", "allotment", "award", "regulation 30", "amalgamation")):
        return "REGULATORY_EVENT"

    return None


def _source_default_event_type(raw_event: RawEvent, text: str) -> str | None:
    candidate = _normalize_text(text)
    source = str(raw_event.source or "").upper()

    if source == "NSE_BULK":
        return "BULK_DEAL"

    if source == "SEBI_INSIDER":
        if "buy" in candidate:
            return "INSIDER_BUY"
        if "sell" in candidate:
            return "INSIDER_SELL"
        return "REGULATORY_EVENT"

    if source == "BSE_ANNOUNCEMENT":
        if "open offer" in candidate or "insider trading" in candidate:
            return "REGULATORY_EVENT"
        if "earnings" in candidate or "financial results" in candidate:
            return "EARNINGS_BEAT"
        if any(token in candidate for token in ("allotment", "award", "approval", "amalgamation")):
            return "REGULATORY_EVENT"

    return None


def detect_sentiment(event_type: str | None, text: str) -> str | None:
    candidate = _normalize_text(text)

    if "closure of trading window" in candidate:
        return "neutral"

    if event_type == "BULK_DEAL":
        if "bulk deals buy" in candidate or "bulk deal buy" in candidate:
            return "positive"
        if "bulk deals sell" in candidate or "bulk deal sell" in candidate:
            return "negative"

    if event_type in {"INSIDER_BUY", "EARNINGS_BEAT", "GUIDANCE_UPGRADE"}:
        return "positive"
    if event_type in {"INSIDER_SELL", "EARNINGS_MISS", "GUIDANCE_DOWNGRADE"}:
        return "negative"

    if event_type == "REGULATORY_EVENT":
        positive_hits = sum(bool(re.search(rf"\b{token}\b", candidate)) for token in POSITIVE_REGULATORY_HINTS)
        negative_hits = sum(bool(re.search(rf"\b{token}\b", candidate)) for token in NEGATIVE_REGULATORY_HINTS)
        if positive_hits > negative_hits:
            return "positive"
        if negative_hits > positive_hits:
            return "negative"
        return "neutral"

    positive_hits = sum(bool(re.search(rf"\b{token}\b", candidate)) for token in POSITIVE_HINTS)
    negative_hits = sum(bool(re.search(rf"\b{token}\b", candidate)) for token in NEGATIVE_HINTS)

    if positive_hits > negative_hits:
        return "positive"
    if negative_hits > positive_hits:
        return "negative"
    return "neutral"


def normalize_event(raw_event: RawEvent, llm: OpenRouterClient) -> StructuredEvent | None:
    if not raw_event.stock_id or not raw_event.stock_symbol:
        return None

    raw_text = f"{raw_event.title} {raw_event.text}".strip()
    sentiment_text = raw_text.split("{", 1)[0].strip() or raw_text
    event_type = detect_event_type(raw_text)
    if not event_type:
        event_type = _source_default_event_type(raw_event, sentiment_text)
    sentiment = detect_sentiment(event_type, sentiment_text)
    confidence = 0.7

    if not event_type:
        llm_type, llm_conf = llm.classify_event(raw_text)
        event_type = llm_type
        confidence = max(confidence, llm_conf)

    if (not sentiment) or sentiment == "neutral":
        llm_sentiment, llm_conf = llm.classify_sentiment(sentiment_text)
        if llm_sentiment:
            sentiment = llm_sentiment
            confidence = max(confidence, llm_conf)

    if not event_type or not sentiment:
        return None

    return StructuredEvent(
        source=raw_event.source,
        source_event_id=raw_event.source_event_id,
        stock_id=raw_event.stock_id,
        stock_symbol=raw_event.stock_symbol,
        event_type=event_type,
        magnitude=extract_magnitude(raw_text),
        sentiment=sentiment,
        confidence=min(confidence, 1.0),
        timestamp=raw_event.published_at,
        raw_text=raw_text,
    )


def normalize_events(events: Iterable[RawEvent], llm: OpenRouterClient) -> list[StructuredEvent]:
    normalized: list[StructuredEvent] = []
    for raw_event in events:
        try:
            structured = normalize_event(raw_event, llm)
            if structured:
                normalized.append(structured)
        except Exception:
            continue
    return normalized
