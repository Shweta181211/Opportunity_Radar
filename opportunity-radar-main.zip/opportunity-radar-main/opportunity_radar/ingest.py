from __future__ import annotations

import csv
import io
import json
import zipfile
from datetime import timedelta
from typing import Any

import requests
from tenacity import retry, stop_after_attempt, wait_exponential

from opportunity_radar.config import Settings
from opportunity_radar.models import RawEvent
from opportunity_radar.utils import (
    make_stock_id,
    parse_datetime_safe,
    stable_event_id,
    utc_now,
)


DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
}

BSE_HEADERS = {
    "Referer": "https://www.bseindia.com/",
    "Origin": "https://www.bseindia.com",
    "X-Requested-With": "XMLHttpRequest",
}

WELL_KNOWN_SYMBOLS = [
    "ABB",
    "ABCAPITAL",
    "ABFRL",
    "ACC",
    "ADANIENT",
    "ADANIPORTS",
    "AMBUJACEM",
    "APOLLOHOSP",
    "ASHOKLEY",
    "ASIANPAINT",
    "AUROPHARMA",
    "AXISBANK",
    "BAJAJFINSV",
    "BAJFINANCE",
    "BANDHANBNK",
    "BANKBARODA",
    "BEL",
    "BHARATFORG",
    "BHARTIARTL",
    "BIOCON",
    "BPCL",
    "BRITANNIA",
    "CANBK",
    "CIPLA",
    "COALINDIA",
    "COLPAL",
    "CONCOR",
    "DABUR",
    "DIVISLAB",
    "DLF",
    "DRREDDY",
    "EICHERMOT",
    "GAIL",
    "GLENMARK",
    "GODREJCP",
    "GRASIM",
    "HAVELLS",
    "HCLTECH",
    "HDFCBANK",
    "HDFCLIFE",
    "HEROMOTOCO",
    "HINDALCO",
    "HINDPETRO",
    "HINDUNILVR",
    "ICICIBANK",
    "ICICIGI",
    "ICICIPRULI",
    "IDEA",
    "INDIGO",
    "INDUSINDBK",
    "INFY",
    "IOC",
    "IRCTC",
    "ITC",
    "JINDALSTEL",
    "JSWSTEEL",
    "JUBLFOOD",
    "KOTAKBANK",
    "LT",
    "LTIM",
    "MARICO",
    "MARUTI",
    "MCDOWELL-N",
    "MOTHERSON",
    "MPHASIS",
    "NAUKRI",
    "NESTLEIND",
    "NMDC",
    "NTPC",
    "OBEROIRLTY",
    "ONGC",
    "PERSISTENT",
    "PETRONET",
    "PIDILITIND",
    "PIIND",
    "PNB",
    "POWERGRID",
    "RECLTD",
    "RELIANCE",
    "SAIL",
    "SBIN",
    "SBILIFE",
    "SHREECEM",
    "SIEMENS",
    "SRF",
    "SUNPHARMA",
    "TATACONSUM",
    "TATAMOTORS",
    "TATAPOWER",
    "TATASTEEL",
    "TCS",
    "TECHM",
    "TITAN",
    "TORNTPHARM",
    "TRENT",
    "ULTRACEMCO",
    "UPL",
    "VEDL",
    "VOLTAS",
    "WIPRO",
    "ZYDUSLIFE",
]


def _get_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(DEFAULT_HEADERS)
    return session


def _prepare_nse_session(session: requests.Session, timeout: int) -> None:
    try:
        session.get("https://www.nseindia.com", timeout=timeout)
    except Exception:
        pass


def _prepare_bse_session(session: requests.Session, timeout: int) -> None:
    try:
        session.get("https://www.bseindia.com", timeout=timeout)
    except Exception:
        pass


def _clean_symbol(symbol: Any) -> str:
    if symbol is None:
        return ""
    return str(symbol).strip().upper().replace(" ", "")


def _cap_rows(rows: list[Any], limit: int) -> list[Any]:
    if limit <= 0:
        return rows
    if len(rows) <= limit:
        return rows
    return rows[:limit]


def _apply_curated_universe(rows: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
    by_symbol: dict[str, dict[str, Any]] = {}

    for row in rows:
        symbol = _clean_symbol(row.get("symbol"))
        if not symbol:
            continue
        current = by_symbol.get(symbol)
        if current is None:
            by_symbol[symbol] = row
            continue
        if current.get("exchange") != "NSE" and row.get("exchange") == "NSE":
            by_symbol[symbol] = row

    curated: list[dict[str, Any]] = []
    for symbol in WELL_KNOWN_SYMBOLS:
        row = by_symbol.get(symbol)
        if row:
            curated.append(row)
        if limit > 0 and len(curated) >= limit:
            break

    return curated


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8), reraise=True)
def _get(
    session: requests.Session,
    url: str,
    timeout: int,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> requests.Response:
    response = session.get(url, timeout=timeout, params=params, headers=headers)
    response.raise_for_status()
    return response


def _date_range_dmy(days: int) -> tuple[str, str]:
    today = utc_now().date()
    start = today - timedelta(days=max(days, 1))
    return start.strftime("%d-%m-%Y"), today.strftime("%d-%m-%Y")


def _date_range_yyyymmdd(days: int) -> tuple[str, str]:
    today = utc_now().date()
    start = today - timedelta(days=max(days, 1))
    return start.strftime("%Y%m%d"), today.strftime("%Y%m%d")


def _parse_csv_rows(raw_text: str) -> list[dict[str, str]]:
    buffer = io.StringIO(raw_text)
    reader = csv.DictReader(buffer)
    return [dict(row) for row in reader]


def fetch_nse_stocks(settings: Settings, session: requests.Session) -> list[dict[str, Any]]:
    try:
        response = _get(session, settings.nse_equity_list_url, settings.request_timeout_seconds)
        rows = _parse_csv_rows(response.text)
    except Exception:
        return []

    stocks: list[dict[str, Any]] = []
    for row in rows:
        symbol = _clean_symbol(row.get("SYMBOL"))
        if not symbol:
            continue
        stocks.append(
            {
                "stock_id": make_stock_id("NSE", symbol),
                "symbol": symbol,
                "exchange": "NSE",
                "name": row.get("NAME OF COMPANY") or row.get("NAME") or symbol,
                "isin": row.get(" ISIN NUMBER") or row.get("ISIN NUMBER") or row.get("ISIN"),
            }
        )
    return stocks


def fetch_bse_stocks(settings: Settings, session: requests.Session) -> list[dict[str, Any]]:
    _prepare_bse_session(session, settings.request_timeout_seconds)
    try:
        response = _get(
            session,
            settings.bse_equity_list_url,
            settings.request_timeout_seconds,
            params={"segment": "Equity", "status": "Active", "Group": "", "Scripcode": ""},
            headers={**session.headers, **BSE_HEADERS},
        )
        content_type = response.headers.get("Content-Type", "").lower()

        if "zip" in content_type or settings.bse_equity_list_url.lower().endswith(".zip"):
            with zipfile.ZipFile(io.BytesIO(response.content)) as zf:
                csv_name = next((name for name in zf.namelist() if name.lower().endswith(".csv")), None)
                if not csv_name:
                    return []
                raw_text = zf.read(csv_name).decode("utf-8", errors="ignore")
                rows = _parse_csv_rows(raw_text)
        elif "json" in content_type:
            payload = response.json()
            rows = payload if isinstance(payload, list) else payload.get("data", [])
        else:
            rows = _parse_csv_rows(response.text)
    except Exception:
        return []

    stocks: list[dict[str, Any]] = []
    for row in rows:
        symbol = _clean_symbol(
            row.get("scrip_id")
            or row.get("Security Id")
            or row.get("SC_CODE")
            or row.get("SCRIP CODE")
            or row.get("symbol")
            or row.get("SCRIP_CD")
        )
        if not symbol:
            continue
        stocks.append(
            {
                "stock_id": make_stock_id("BSE", symbol),
                "symbol": symbol,
                "exchange": "BSE",
                "name": row.get("Scrip_Name") or row.get("Security Name") or row.get("SC_NAME") or symbol,
                "isin": row.get("ISIN_NUMBER") or row.get("ISIN") or row.get("ISIN_NO"),
                "bse_code": str(row.get("SCRIP_CD") or row.get("SC_CODE") or "").strip(),
            }
        )
    return stocks


def fetch_nse_bulk_deals(settings: Settings, session: requests.Session) -> list[RawEvent]:
    _prepare_nse_session(session, settings.request_timeout_seconds)
    from_date, to_date = _date_range_dmy(max(settings.signal_lookback_days, 14))

    rows: list[dict[str, Any]] = []
    for option_type in ("bulk_deals", "block_deals"):
        params = {"optionType": option_type, "from": from_date, "to": to_date}
        try:
            response = _get(
                session,
                settings.nse_bulk_deals_url,
                settings.request_timeout_seconds,
                params=params,
            )
            payload = response.json()
            option_rows = payload if isinstance(payload, list) else payload.get("data", [])
            for row in option_rows:
                row["_deal_kind"] = option_type
            rows.extend(option_rows)
        except Exception:
            continue

    if not rows:
        return []

    try:
        events: list[RawEvent] = []
        for row in rows:
            symbol = _clean_symbol(row.get("BD_SYMBOL") or row.get("symbol") or row.get("symbolName"))
            if not symbol:
                continue
            date_text = row.get("BD_DT_ORDER") or row.get("BD_DT_DATE") or row.get("date") or row.get("dealDate")
            deal_kind = row.get("_deal_kind", "bulk_deals")
            buy_sell = row.get("BD_BUY_SELL") or ""
            qty = row.get("BD_QTY_TRD") or row.get("quantity") or ""
            price = row.get("BD_TP_WATP") or row.get("price") or ""
            text = json.dumps(row, default=str)
            events.append(
                RawEvent(
                    source="NSE_BULK",
                    source_event_id=stable_event_id("nse_bulk", row),
                    stock_id=make_stock_id("NSE", symbol),
                    stock_symbol=symbol,
                    published_at=parse_datetime_safe(date_text),
                    title=f"NSE {deal_kind.replace('_', ' ')} {buy_sell} for {symbol}",
                    text=f"{buy_sell} qty={qty} price={price}. {text}",
                    payload=row,
                )
            )
        return _cap_rows(events, settings.max_events_per_source)
    except Exception:
        return []


def fetch_bse_announcements(
    settings: Settings,
    session: requests.Session,
    bse_code_symbol_map: dict[str, str] | None = None,
) -> list[RawEvent]:
    _prepare_bse_session(session, settings.request_timeout_seconds)
    from_date, to_date = _date_range_yyyymmdd(7)
    events: list[RawEvent] = []
    seen_ids: set[str] = set()
    total_pages = 1
    max_pages = 5

    for page in range(1, max_pages + 1):
        params = {
            "pageno": page,
            "strCat": "-1",
            "strPrevDate": "",
            "strScrip": "",
            "strSearch": "P",
            "strToDate": to_date,
            "strFromDate": from_date,
            "strPeriod": "1M",
            "strType": "C",
            "subcategory": "-1",
        }
        try:
            response = _get(
                session,
                settings.bse_announcements_url,
                settings.request_timeout_seconds,
                params=params,
                headers={**session.headers, **BSE_HEADERS},
            )
            payload = response.json()
            rows = payload if isinstance(payload, list) else payload.get("Table", payload.get("data", []))
        except Exception:
            continue

        if not rows:
            break

        try:
            total_pages = int(rows[0].get("TotalPageCnt", total_pages) or total_pages)
        except Exception:
            pass

        for row in rows:
            source_event_id = str(row.get("NEWSID") or stable_event_id("bse_ann", row))
            if source_event_id in seen_ids:
                continue
            seen_ids.add(source_event_id)

            bse_code = str(
                row.get("SCRIP_CD")
                or row.get("SC_CODE")
                or row.get("scrip_code")
                or ""
            ).strip()
            mapped_symbol = (bse_code_symbol_map or {}).get(bse_code)
            symbol = _clean_symbol(
                mapped_symbol
                or row.get("symbol")
                or row.get("Security Id")
                or row.get("scrip_id")
                or bse_code
            )
            if not symbol:
                continue

            headline = (
                row.get("NEWSSUB")
                or row.get("HEADLINE")
                or row.get("headline")
                or row.get("SUBCATNAME")
                or "BSE announcement"
            )
            category = row.get("CATEGORYNAME") or ""
            body = row.get("ATTACHMENTNAME") or row.get("details") or ""
            date_text = row.get("DissemDT") or row.get("DT_TM") or row.get("NEWS_DT") or row.get("date")
            events.append(
                RawEvent(
                    source="BSE_ANNOUNCEMENT",
                    source_event_id=source_event_id,
                    stock_id=make_stock_id("BSE", symbol),
                    stock_symbol=symbol,
                    published_at=parse_datetime_safe(date_text),
                    title=str(headline),
                    text=f"{headline} category={category} attachment={body}",
                    payload=row,
                )
            )

            if settings.max_events_per_source > 0 and len(events) >= settings.max_events_per_source:
                return events

        if page >= total_pages:
            break

    return events


def fetch_sebi_insider_events(settings: Settings, session: requests.Session) -> list[RawEvent]:
    _prepare_nse_session(session, settings.request_timeout_seconds)
    from_date, to_date = _date_range_dmy(max(settings.signal_lookback_days, 14))

    try:
        response = _get(
            session,
            settings.sebi_insider_url,
            settings.request_timeout_seconds,
            params={"index": "equities", "from_date": from_date, "to_date": to_date},
        )
        payload = response.json()
        rows = payload if isinstance(payload, list) else payload.get("data", payload.get("newslist", []))
    except Exception:
        return []

    events: list[RawEvent] = []
    for row in rows:
        transaction_type = row.get("tdpTransactionType") or row.get("transactionType") or ""
        title = str(row.get("title") or row.get("HEADLINE") or row.get("company") or "Insider filing")
        symbol = _clean_symbol(row.get("symbol") or row.get("scrip") or row.get("companyCode"))
        if not symbol:
            continue
        date_text = row.get("date") or row.get("created")
        source_event_id = str(row.get("pid") or row.get("did") or stable_event_id("sebi_insider", row))
        events.append(
            RawEvent(
                source="SEBI_INSIDER",
                source_event_id=source_event_id,
                stock_id=make_stock_id("NSE", symbol),
                stock_symbol=symbol,
                published_at=parse_datetime_safe(date_text, fallback=utc_now()),
                title=f"{title} {transaction_type}".strip(),
                text=json.dumps(row, default=str),
                payload=row,
            )
        )
        if settings.max_events_per_source > 0 and len(events) >= settings.max_events_per_source:
            break
    return events


def collect_stock_universe(settings: Settings) -> list[dict[str, Any]]:
    session = _get_session()
    nse = fetch_nse_stocks(settings, session)
    bse = fetch_bse_stocks(settings, session)

    if not bse:
        for event in fetch_bse_announcements(settings, session):
            bse.append(
                {
                    "stock_id": event.stock_id,
                    "symbol": event.stock_symbol,
                    "exchange": "BSE",
                    "name": event.stock_symbol,
                    "isin": None,
                }
            )

    merged: dict[str, dict[str, Any]] = {}
    for row in nse + bse:
        merged[row["stock_id"]] = row
    all_rows = sorted(merged.values(), key=lambda row: row.get("stock_id", ""))

    if settings.use_curated_universe:
        curated = _apply_curated_universe(all_rows, settings.max_stock_universe)
        if curated:
            return curated

    if settings.fast_mode:
        return _cap_rows(all_rows, settings.max_stock_universe)
    return all_rows


def collect_raw_events(settings: Settings) -> list[RawEvent]:
    session = _get_session()
    bse_stocks = fetch_bse_stocks(settings, session)
    bse_code_symbol_map = {
        str(row.get("bse_code") or ""): str(row.get("symbol") or "")
        for row in bse_stocks
        if row.get("bse_code") and row.get("symbol")
    }
    nse_bulk = fetch_nse_bulk_deals(settings, session)
    bse_ann = fetch_bse_announcements(settings, session, bse_code_symbol_map=bse_code_symbol_map)
    sebi = fetch_sebi_insider_events(settings, session)
    combined = nse_bulk + bse_ann + sebi
    if settings.fast_mode:
        return _cap_rows(combined, settings.max_total_events)
    return combined
