from __future__ import annotations

from datetime import datetime
from typing import Any

import requests

from opportunity_radar.config import Settings


def _recommendation(score: float) -> str:
    if score >= 70:
        return "Strong Buy"
    if score >= 60:
        return "Buy"
    if score <= 30:
        return "Strong Risk"
    if score <= 45:
        return "Risk"
    return "Watch"


def _confidence_band(confidence_multiplier: float, action_score: float) -> str:
    if confidence_multiplier >= 1.15 and action_score >= 8:
        return "High"
    if confidence_multiplier >= 1.0 and action_score >= 4:
        return "Medium"
    return "Low"


def _emoji_for_alert(alert_type: str) -> str:
    if "OPPORTUNITY" in alert_type:
        return "🟢"
    if "RISK" in alert_type:
        return "🔴"
    return "🟡"


def _confidence_emoji(conf: str) -> str:
    if conf == "High":
        return "🔥"
    if conf == "Medium":
        return "⚡"
    return "💤"


def build_watchlist_alert_rows(
    score_rows: list[dict[str, Any]],
    symbols: list[str],
) -> list[dict[str, Any]]:
    symbol_set = {str(symbol or "").strip().upper() for symbol in symbols if str(symbol or "").strip()}
    if not symbol_set:
        return []

    alerts: list[dict[str, Any]] = []
    for row in score_rows:
        symbol = str(row.get("stock_symbol", "")).strip().upper()
        if symbol not in symbol_set:
            continue

        score = float(row.get("final_score", 50.0) or 50.0)
        action_score = abs(score - 50.0)
        confidence_multiplier = float(row.get("confidence_multiplier", 1.0) or 1.0)
        confidence = _confidence_band(confidence_multiplier, action_score)
        recommendation = _recommendation(score)

        if score >= 60:
            alert_type = "WATCHLIST_OPPORTUNITY"
        elif score <= 40:
            alert_type = "WATCHLIST_RISK"
        else:
            alert_type = "WATCHLIST_WATCH"

        alerts.append(
            {
                "stock_symbol": symbol,
                "score": round(score, 1),
                "recommendation": recommendation,
                "confidence": confidence,
                "alert_type": alert_type,
                "message": str(row.get("explanation", "")),
                "action_score": action_score,
            }
        )

    alerts.sort(key=lambda item: item.get("action_score", 0.0), reverse=True)
    return alerts


def build_telegram_watchlist_message(
    user_name: str,
    run_date: str,
    watchlist_alerts: list[dict[str, Any]],
) -> str:
    ts = run_date
    try:
        ts = datetime.fromisoformat(run_date.replace("Z", "+00:00")).strftime("%d-%b-%Y %H:%M UTC")
    except Exception:
        pass

    lines = [
        "━━━━━━━━━━━━━━━━━━━━",
        "⚡ OPPORTUNITY RADAR",
        "━━━━━━━━━━━━━━━━━━━━",
        f"📅 {ts}",
        f"👤 {user_name}",
        "",
    ]

    if not watchlist_alerts:
        lines.append("📭 No watchlist matches in this scan.")
        lines.append("")
        lines.append("💡 Add stocks to your watchlist to receive personalized alerts.")
        lines.append("")
        lines.append("━━━━━━━━━━━━━━━━━━━━")
        lines.append("🤖 Opportunity Radar")
        return "\n".join(lines)

    # Separate by category
    opportunities = [a for a in watchlist_alerts if "OPPORTUNITY" in a.get("alert_type", "")]
    risks = [a for a in watchlist_alerts if "RISK" in a.get("alert_type", "")]
    watches = [a for a in watchlist_alerts if "WATCH" in a.get("alert_type", "")]

    if opportunities:
        lines.append("🟢 OPPORTUNITIES")
        lines.append("─────────────────")
        for alert in opportunities[:5]:
            conf_emoji = _confidence_emoji(alert.get("confidence", "Low"))
            lines.append(
                f"  📈 {alert.get('stock_symbol', '')}  •  {alert.get('score', 0):.1f}  •  "
                f"{alert.get('recommendation', 'Watch')}"
            )
            lines.append(f"     {conf_emoji} Confidence: {alert.get('confidence', 'Low')}")
        lines.append("")

    if risks:
        lines.append("🔴 RISKS")
        lines.append("─────────────────")
        for alert in risks[:5]:
            conf_emoji = _confidence_emoji(alert.get("confidence", "Low"))
            lines.append(
                f"  📉 {alert.get('stock_symbol', '')}  •  {alert.get('score', 0):.1f}  •  "
                f"{alert.get('recommendation', 'Watch')}"
            )
            lines.append(f"     {conf_emoji} Confidence: {alert.get('confidence', 'Low')}")
        lines.append("")

    if watches:
        lines.append("🟡 WATCHLIST")
        lines.append("─────────────────")
        for alert in watches[:5]:
            lines.append(
                f"  👁 {alert.get('stock_symbol', '')}  •  {alert.get('score', 0):.1f}  •  "
                f"{alert.get('recommendation', 'Watch')}"
            )
        lines.append("")

    lines.append(f"📊 Total symbols tracked: {len(watchlist_alerts)}")
    lines.append("")
    lines.append("━━━━━━━━━━━━━━━━━━━━")
    lines.append("🤖 Opportunity Radar")
    return "\n".join(lines)


def send_telegram_message(settings: Settings, chat_id: str, text: str) -> tuple[bool, str | None]:
    token = settings.telegram_bot_token.strip()
    if not token:
        return False, "TELEGRAM_BOT_TOKEN is not configured."

    url = f"{settings.telegram_api_url.rstrip('/')}/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": text,
        "disable_web_page_preview": True,
    }

    try:
        response = requests.post(
            url,
            json=payload,
            timeout=settings.request_timeout_seconds,
        )
        response.raise_for_status()
        body = response.json()
        if not body.get("ok"):
            return False, str(body)
        return True, None
    except Exception as error:
        return False, str(error)


def push_watchlist_updates_for_all_users(
    db: Any,
    settings: Settings,
    run_date: str,
    score_rows: list[dict[str, Any]],
) -> dict[str, int]:
    if not settings.telegram_updates_enabled:
        return {"attempted": 0, "sent": 0, "failed": 0, "skipped": 0}

    subscribers = db.fetch_watchlist_subscribers()
    attempted = 0
    sent = 0
    failed = 0
    skipped = 0

    for subscriber in subscribers:
        user_id = str(subscriber.get("user_id", "")).strip()
        name = str(subscriber.get("display_name", user_id)).strip() or user_id
        chat_id = str(subscriber.get("telegram_chat_id", "")).strip()
        symbols = [str(symbol).strip().upper() for symbol in subscriber.get("symbols", []) if str(symbol).strip()]

        if not user_id or not chat_id or not symbols:
            skipped += 1
            continue

        attempted += 1
        alerts = build_watchlist_alert_rows(score_rows, symbols)
        message = build_telegram_watchlist_message(name, run_date, alerts)

        ok, error = send_telegram_message(settings, chat_id, message)
        if ok:
            sent += 1
            db.log_user_notification(
                user_id=user_id,
                run_date=run_date,
                channel="telegram",
                status="sent",
                message=f"Watchlist update sent for {len(alerts)} symbols.",
            )
        else:
            failed += 1
            db.log_user_notification(
                user_id=user_id,
                run_date=run_date,
                channel="telegram",
                status="failed",
                message=(error or "Unknown Telegram error")[:400],
            )

    return {
        "attempted": attempted,
        "sent": sent,
        "failed": failed,
        "skipped": skipped,
    }
