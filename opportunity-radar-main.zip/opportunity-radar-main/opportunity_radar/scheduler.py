from __future__ import annotations

from apscheduler.schedulers.blocking import BlockingScheduler

from opportunity_radar.config import get_settings
from opportunity_radar.pipeline import run_daily_pipeline


def start_scheduler() -> None:
    settings = get_settings()
    scheduler = BlockingScheduler(timezone="Asia/Kolkata")

    def _job() -> None:
        try:
            summary = run_daily_pipeline(settings=settings)
            print("Daily pipeline completed:", summary)
        except RuntimeError as error:
            print(f"Daily pipeline failed: {error}")

    scheduler.add_job(
        _job,
        trigger="cron",
        hour=settings.scheduler_hour_ist,
        minute=settings.scheduler_minute_ist,
        id="opportunity_radar_daily",
        replace_existing=True,
    )
    print(
        "Scheduler started. Daily run at "
        f"{settings.scheduler_hour_ist:02d}:{settings.scheduler_minute_ist:02d} IST"
    )
    scheduler.start()
