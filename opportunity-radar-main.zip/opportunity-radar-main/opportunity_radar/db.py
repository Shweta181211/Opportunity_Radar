from __future__ import annotations

from datetime import timedelta
from typing import Any

from postgrest.exceptions import APIError
from supabase import Client, create_client
from tenacity import retry, stop_after_attempt, wait_fixed

from opportunity_radar.config import Settings
from opportunity_radar.models import RawEvent, ScoreResult, Signal, StructuredEvent
from opportunity_radar.utils import utc_now


class Database:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.backend_name = "supabase"
        self.client: Client | None = None
        if settings.supabase_url and settings.supabase_key:
            self.client = create_client(settings.supabase_url, settings.supabase_key)

    def is_configured(self) -> bool:
        return self.client is not None

    def _require_client(self) -> Client:
        if not self.client:
            raise RuntimeError("Supabase is not configured. Set SUPABASE_URL and SUPABASE_KEY.")
        return self.client

    def _raise_for_api_error(self, error: APIError) -> None:
        message = str(error)
        if "Invalid API key" in message or "'code': 401" in message:
            key_hint = ""
            if self.settings.supabase_key.startswith("sb_publishable_"):
                key_hint = (
                    " Detected an sb_publishable key. For server-side Python, use the project anon JWT or service-role key."
                )
            raise RuntimeError(
                "Supabase authentication failed. Update SUPABASE_KEY with a valid anon/service-role API key from your Supabase project settings."
                + key_hint
            ) from error
        if "PGRST205" in message or "Could not find the table" in message:
            raise RuntimeError(
                "Supabase schema is missing required tables. Run sql/schema.sql in the Supabase SQL editor, then rerun the pipeline."
            ) from error
        raise RuntimeError(f"Supabase request failed: {message}") from error

    def _execute(self, query: Any) -> Any:
        try:
            return query.execute()
        except APIError as error:
            self._raise_for_api_error(error)

    def validate_connection(self) -> tuple[bool, str | None]:
        if not self.is_configured():
            return False, "Missing Supabase credentials. Configure SUPABASE_URL and SUPABASE_KEY in .env."
        client = self._require_client()
        try:
            self._execute(client.table("stocks").select("stock_id").limit(1))
        except RuntimeError as error:
            return False, str(error)
        return True, None

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(1), reraise=True)
    def upsert_stocks(self, rows: list[dict[str, Any]]) -> int:
        if not rows:
            return 0
        client = self._require_client()
        self._execute(client.table("stocks").upsert(rows, on_conflict="stock_id"))
        return len(rows)

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(1), reraise=True)
    def insert_raw_events(self, events: list[RawEvent]) -> int:
        if not events:
            return 0
        client = self._require_client()
        rows = [event.model_dump(mode="json") for event in events]
        self._execute(client.table("raw_events").upsert(rows, on_conflict="source,source_event_id"))
        return len(rows)

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(1), reraise=True)
    def insert_structured_events(self, events: list[StructuredEvent]) -> int:
        if not events:
            return 0
        client = self._require_client()
        rows = [event.model_dump(mode="json") for event in events]
        self._execute(
            client.table("structured_events").upsert(rows, on_conflict="source,source_event_id")
        )
        return len(rows)

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(1), reraise=True)
    def insert_signals(self, signals: list[Signal]) -> int:
        if not signals:
            return 0
        client = self._require_client()
        rows = [signal.model_dump(mode="json") for signal in signals]
        self._execute(client.table("signals").upsert(rows, on_conflict="stock_id,signal_type,event_ts"))
        return len(rows)

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(1), reraise=True)
    def upsert_scores(self, scores: list[ScoreResult]) -> int:
        if not scores:
            return 0
        client = self._require_client()
        rows = [score.model_dump(mode="json") for score in scores]
        self._execute(client.table("scores").upsert(rows, on_conflict="run_date,stock_id"))
        return len(rows)

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(1), reraise=True)
    def insert_alerts(self, alerts: list[dict[str, Any]]) -> int:
        if not alerts:
            return 0
        client = self._require_client()
        self._execute(client.table("alerts").upsert(alerts, on_conflict="run_date,stock_id"))
        return len(alerts)

    def fetch_stocks(self) -> list[dict[str, Any]]:
        client = self._require_client()
        result = self._execute(client.table("stocks").select("*"))
        return result.data or []

    def fetch_recent_raw_events(
        self, limit: int = 200, source: str | None = None, stock_id: str | None = None
    ) -> list[dict[str, Any]]:
        client = self._require_client()
        query = (
            client.table("raw_events")
            .select("*")
            .order("published_at", desc=True)
            .limit(limit)
        )
        if source:
            query = query.eq("source", source)
        if stock_id:
            query = query.eq("stock_id", stock_id)
        result = self._execute(query)
        return result.data or []

    def fetch_recent_signals(self, days: int) -> list[dict[str, Any]]:
        client = self._require_client()
        cutoff = (utc_now() - timedelta(days=days)).isoformat()
        result = (
            client.table("signals")
            .select("*")
            .gte("event_ts", cutoff)
            .order("event_ts", desc=True)
        )
        result = self._execute(result)
        return result.data or []

    def fetch_latest_scores(self, limit: int = 500) -> list[dict[str, Any]]:
        client = self._require_client()
        latest = (
            client.table("scores")
            .select("run_date")
            .order("run_date", desc=True)
            .limit(1)
        )
        latest = self._execute(latest)
        if not latest.data:
            return []
        run_date = latest.data[0]["run_date"]
        result = (
            client.table("scores")
            .select("*")
            .eq("run_date", run_date)
            .order("rank", desc=False)
            .limit(limit)
        )
        result = self._execute(result)
        return result.data or []

    def fetch_stock_detail(self, stock_id: str) -> dict[str, Any]:
        client = self._require_client()

        score = (
            client.table("scores")
            .select("*")
            .eq("stock_id", stock_id)
            .order("run_date", desc=True)
            .limit(1)
        )
        score = self._execute(score)
        signals = (
            client.table("signals")
            .select("*")
            .eq("stock_id", stock_id)
            .order("event_ts", desc=True)
            .limit(30)
        )
        signals = self._execute(signals)
        events = (
            client.table("structured_events")
            .select("*")
            .eq("stock_id", stock_id)
            .order("timestamp", desc=True)
            .limit(30)
        )
        events = self._execute(events)
        return {
            "score": score.data[0] if score.data else None,
            "signals": signals.data or [],
            "events": events.data or [],
        }

    def fetch_latest_alerts(self, limit: int = 30) -> list[dict[str, Any]]:
        client = self._require_client()
        latest = (
            client.table("alerts")
            .select("run_date")
            .order("run_date", desc=True)
            .limit(1)
        )
        latest = self._execute(latest)
        if not latest.data:
            return []

        run_date = latest.data[0]["run_date"]
        result = (
            client.table("alerts")
            .select("*")
            .eq("run_date", run_date)
            .order("created_at", desc=True)
            .limit(limit)
        )
        result = self._execute(result)
        return result.data or []

    def upsert_user_profile(
        self,
        user_id: str,
        display_name: str,
        telegram_chat_id: str | None = None,
    ) -> dict[str, Any]:
        client = self._require_client()
        payload = {
            "user_id": user_id,
            "display_name": display_name,
            "telegram_chat_id": telegram_chat_id or None,
            "updated_at": utc_now().isoformat(),
        }
        self._execute(client.table("users").upsert([payload], on_conflict="user_id"))
        result = self._execute(client.table("users").select("*").eq("user_id", user_id).limit(1))
        return (result.data or [payload])[0]

    def fetch_user_profile(self, user_id: str) -> dict[str, Any] | None:
        client = self._require_client()
        result = self._execute(
            client.table("users").select("*").eq("user_id", user_id).limit(1)
        )
        if not result.data:
            return None
        return result.data[0]

    def add_user_watchlist_symbols(self, user_id: str, symbols: list[str]) -> int:
        clean_symbols = sorted({str(symbol or "").strip().upper() for symbol in symbols if str(symbol or "").strip()})
        if not clean_symbols:
            return 0
        client = self._require_client()
        rows = [{"user_id": user_id, "stock_symbol": symbol} for symbol in clean_symbols]
        self._execute(client.table("user_watchlists").upsert(rows, on_conflict="user_id,stock_symbol"))
        return len(rows)

    def fetch_user_watchlist_symbols(self, user_id: str) -> list[str]:
        client = self._require_client()
        result = self._execute(
            client.table("user_watchlists")
            .select("stock_symbol")
            .eq("user_id", user_id)
            .order("stock_symbol")
        )
        return [str(row.get("stock_symbol", "")).upper() for row in (result.data or []) if row.get("stock_symbol")]

    def remove_user_watchlist_symbol(self, user_id: str, stock_symbol: str) -> None:
        client = self._require_client()
        self._execute(
            client.table("user_watchlists")
            .delete()
            .eq("user_id", user_id)
            .eq("stock_symbol", stock_symbol.upper())
        )

    def clear_user_watchlist(self, user_id: str) -> None:
        client = self._require_client()
        self._execute(client.table("user_watchlists").delete().eq("user_id", user_id))

    def fetch_watchlist_subscribers(self) -> list[dict[str, Any]]:
        client = self._require_client()
        users = self._execute(client.table("users").select("user_id,display_name,telegram_chat_id"))
        watchlist = self._execute(client.table("user_watchlists").select("user_id,stock_symbol"))

        symbols_by_user: dict[str, list[str]] = {}
        for row in watchlist.data or []:
            uid = str(row.get("user_id") or "")
            symbol = str(row.get("stock_symbol") or "").strip().upper()
            if not uid or not symbol:
                continue
            symbols_by_user.setdefault(uid, []).append(symbol)

        subscribers: list[dict[str, Any]] = []
        for user in users.data or []:
            uid = str(user.get("user_id") or "")
            chat_id = str(user.get("telegram_chat_id") or "").strip()
            symbols = sorted(set(symbols_by_user.get(uid, [])))
            if not uid or not chat_id or not symbols:
                continue
            subscribers.append(
                {
                    "user_id": uid,
                    "display_name": str(user.get("display_name") or uid),
                    "telegram_chat_id": chat_id,
                    "symbols": symbols,
                }
            )
        return subscribers

    def log_user_notification(
        self,
        user_id: str,
        run_date: str,
        channel: str,
        status: str,
        message: str,
    ) -> None:
        client = self._require_client()
        payload = {
            "user_id": user_id,
            "run_date": run_date,
            "channel": channel,
            "status": status,
            "message": message,
            "created_at": utc_now().isoformat(),
        }
        self._execute(
            client.table("user_notification_logs").upsert(
                [payload],
                on_conflict="user_id,run_date,channel",
            )
        )


def get_database(settings: Settings) -> Any:
    primary = Database(settings)
    ok, message = primary.validate_connection()
    if ok:
        return primary
    if settings.allow_local_db_fallback:
        from opportunity_radar.local_db import LocalDatabase

        return LocalDatabase(settings, fallback_reason=message)
    return primary
