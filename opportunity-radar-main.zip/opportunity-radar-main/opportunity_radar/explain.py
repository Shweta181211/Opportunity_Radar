from __future__ import annotations

import re

from opportunity_radar.models import ScoreResult, Signal
from opportunity_radar.openrouter import OpenRouterClient


TOKEN_PATTERN = re.compile(r"[A-Za-z_]{4,}")


def _signal_fact(signal: Signal) -> str:
    label = signal.signal_type.replace("_", " ").lower()
    return f"{label} ({signal.strength:+.0f})"


def _score_label(final_score: float) -> str:
    if final_score >= 60:
        return "opportunity"
    if final_score <= 40:
        return "risk"
    return "neutral"


def _top_facts(signals: list[Signal], positive: bool, limit: int = 2) -> list[str]:
    subset = [signal for signal in signals if (signal.strength > 0) == positive]
    subset.sort(key=lambda item: abs(item.strength), reverse=True)
    return [_signal_fact(signal) for signal in subset[:limit]]


def generate_stock_explanation(
    score: ScoreResult,
    signals: list[Signal],
    llm: OpenRouterClient,
) -> str:
    if not signals:
        return (
            f"Score {score.final_score:.1f} (neutral). "
            "No recent high-impact signals were found in the lookback window."
        )

    positive_total = sum(signal.strength for signal in signals if signal.strength > 0)
    negative_total = sum(abs(signal.strength) for signal in signals if signal.strength < 0)

    positive_facts = _top_facts(signals, positive=True)
    negative_facts = _top_facts(signals, positive=False)

    signal_count = len(signals)
    label = _score_label(score.final_score)

    if positive_total > negative_total * 1.05:
        core = positive_facts or [_signal_fact(signal) for signal in signals[:2]]
        deterministic = (
            f"Score {score.final_score:.1f} ({label}). "
            f"Main positive drivers: {', '.join(core)}. "
            f"Confidence x{score.confidence_multiplier:.2f}, recency x{score.recency_multiplier:.2f}, "
            f"signals considered: {signal_count}."
        )
        if negative_facts:
            deterministic += f" Counter-signal: {negative_facts[0]}."
        bias = "bullish"
    elif negative_total > positive_total * 1.05:
        core = negative_facts or [_signal_fact(signal) for signal in signals[:2]]
        deterministic = (
            f"Score {score.final_score:.1f} ({label}). "
            f"Main negative drivers: {', '.join(core)}. "
            f"Confidence x{score.confidence_multiplier:.2f}, recency x{score.recency_multiplier:.2f}, "
            f"signals considered: {signal_count}."
        )
        if positive_facts:
            deterministic += f" Counter-signal: {positive_facts[0]}."
        bias = "bearish"
    else:
        top_signals = sorted(signals, key=lambda item: abs(item.strength), reverse=True)[:3]
        core = [_signal_fact(signal) for signal in top_signals]
        deterministic = (
            f"Score {score.final_score:.1f} ({label}). "
            f"Mixed drivers: {', '.join(core)}. "
            f"Confidence x{score.confidence_multiplier:.2f}, recency x{score.recency_multiplier:.2f}, "
            f"signals considered: {signal_count}."
        )
        bias = "mixed"

    facts = core + [f"net bias {bias}", f"final score {score.final_score:.1f}"]

    phrased = llm.phrase_explanation(facts)
    if not phrased:
        return deterministic

    # Guardrail: require at least one fact token to appear in the generated sentence.
    anchors = {
        token.lower()
        for fact in facts
        for token in TOKEN_PATTERN.findall(fact)
        if token.lower() not in {"final", "score", "signals"}
    }
    if anchors and not any(token in phrased.lower() for token in anchors):
        return deterministic

    return phrased


def generate_alerts(
    scores: list[ScoreResult],
    threshold: float,
    top_n: int,
) -> list[dict]:
    alerts: list[dict] = []

    bearish_threshold = max(0.0, 100.0 - threshold)

    for score in scores:
        if score.final_score < threshold:
            continue
        if len(alerts) >= top_n:
            break
        alerts.append(
            {
                "run_date": score.run_date.isoformat(),
                "stock_id": score.stock_id,
                "stock_symbol": score.stock_symbol,
                "alert_type": "TOP_OPPORTUNITY",
                "message": (
                    f"Stock {score.stock_symbol} shows strong opportunity "
                    f"with score {score.final_score:.1f}. {score.explanation}"
                ),
            }
        )

    remaining = max(top_n - len(alerts), 0)
    if remaining <= 0:
        return alerts

    risk_count = min(max(remaining, 3), top_n)
    for score in reversed(scores):
        if score.final_score > bearish_threshold:
            continue
        if any(alert.get("stock_id") == score.stock_id for alert in alerts):
            continue
        alerts.append(
            {
                "run_date": score.run_date.isoformat(),
                "stock_id": score.stock_id,
                "stock_symbol": score.stock_symbol,
                "alert_type": "RISK_ALERT",
                "message": (
                    f"Stock {score.stock_symbol} shows elevated downside risk "
                    f"with score {score.final_score:.1f}. {score.explanation}"
                ),
            }
        )
        if len(alerts) >= top_n or risk_count <= 1:
            break
        risk_count -= 1

    return alerts
