from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Iterable

from opportunity_radar.models import ScoreResult, Signal
from opportunity_radar.utils import clamp


def _sum_category(signals: list[Signal], category: str) -> float:
    return sum(signal.strength for signal in signals if signal.category == category)


def _recency_multiplier(latest_ts: datetime | None, now: datetime) -> float:
    if latest_ts is None:
        return 1.0

    delta_days = (now - latest_ts).total_seconds() / 86400
    if delta_days < 1:
        return 1.3
    if delta_days <= 3:
        return 1.1
    if delta_days <= 7:
        return 1.0
    return 0.7


def _confidence_multiplier(
    signals: list[Signal], insider_score: float, earnings_score: float
) -> float:
    if not signals:
        return 1.0

    adjustment = 0.0

    if insider_score and earnings_score and insider_score * earnings_score > 0:
        adjustment += 0.2

    if sum(abs(signal.strength) >= 20 for signal in signals) >= 2:
        adjustment += 0.2

    if any(abs(signal.magnitude) >= 2 for signal in signals):
        adjustment += 0.1

    has_positive = any(signal.strength > 0 for signal in signals)
    has_negative = any(signal.strength < 0 for signal in signals)
    if has_positive and has_negative:
        adjustment -= 0.3

    avg_conf = sum(signal.confidence for signal in signals) / len(signals)
    if avg_conf < 0.55:
        adjustment -= 0.2

    return max(0.5, 1.0 + adjustment)


def _density_bonus(signal_count: int) -> float:
    if signal_count >= 3:
        return 10.0
    if signal_count == 2:
        return 5.0
    return 0.0


def compute_stock_score(
    stock_id: str,
    stock_symbol: str,
    signals: list[Signal],
    run_date: datetime,
) -> ScoreResult:
    if not signals:
        return ScoreResult(
            run_date=run_date,
            stock_id=stock_id,
            stock_symbol=stock_symbol,
            insider_score=0.0,
            earnings_score=0.0,
            sentiment_score=0.0,
            event_score=0.0,
            raw_score=50.0,
            density_bonus=0.0,
            confidence_multiplier=1.0,
            recency_multiplier=1.0,
            final_score=50.0,
            explanation="",
        )

    insider_score = _sum_category(signals, "insider")
    earnings_score = _sum_category(signals, "earnings")
    sentiment_score = _sum_category(signals, "sentiment")
    event_score = _sum_category(signals, "event")

    weighted = (
        0.3 * insider_score
        + 0.3 * earnings_score
        + 0.2 * sentiment_score
        + 0.2 * event_score
    )
    raw_score = clamp(50.0 + weighted, 0.0, 100.0)

    confidence_multiplier = _confidence_multiplier(signals, insider_score, earnings_score)
    recency_multiplier = _recency_multiplier(
        latest_ts=max(signal.event_ts for signal in signals),
        now=run_date,
    )
    density_bonus = _density_bonus(len(signals))

    adjusted_score = raw_score + density_bonus
    final_score = clamp(
        50.0 + (adjusted_score - 50.0) * confidence_multiplier * recency_multiplier,
        0.0,
        100.0,
    )

    return ScoreResult(
        run_date=run_date,
        stock_id=stock_id,
        stock_symbol=stock_symbol,
        insider_score=insider_score,
        earnings_score=earnings_score,
        sentiment_score=sentiment_score,
        event_score=event_score,
        raw_score=raw_score,
        density_bonus=density_bonus,
        confidence_multiplier=confidence_multiplier,
        recency_multiplier=recency_multiplier,
        final_score=final_score,
        explanation="",
    )


def rank_stocks(
    stocks: list[dict],
    signals: Iterable[Signal],
    run_date: datetime,
) -> list[ScoreResult]:
    by_stock: dict[str, list[Signal]] = defaultdict(list)
    for signal in signals:
        by_stock[signal.stock_id].append(signal)

    results: list[ScoreResult] = []
    for stock in stocks:
        stock_id = stock["stock_id"]
        stock_symbol = stock.get("symbol", stock_id)
        result = compute_stock_score(
            stock_id=stock_id,
            stock_symbol=stock_symbol,
            signals=by_stock.get(stock_id, []),
            run_date=run_date,
        )
        results.append(result)

    results.sort(key=lambda row: (-row.final_score, row.stock_id))
    for idx, row in enumerate(results, start=1):
        row.rank = idx
    return results
