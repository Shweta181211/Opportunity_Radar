from __future__ import annotations

from datetime import datetime
from time import perf_counter

from opportunity_radar.config import Settings, get_settings
from opportunity_radar.db import Database, get_database
from opportunity_radar.explain import generate_alerts, generate_stock_explanation
from opportunity_radar.ingest import collect_raw_events, collect_stock_universe
from opportunity_radar.models import Signal
from opportunity_radar.notifications import push_watchlist_updates_for_all_users
from opportunity_radar.normalize import normalize_events
from opportunity_radar.openrouter import OpenRouterClient
from opportunity_radar.scoring import rank_stocks
from opportunity_radar.signals import generate_signals
from opportunity_radar.utils import parse_datetime_safe, utc_now


def _coerce_signal(row: dict) -> Signal:
    payload = dict(row)
    payload["event_ts"] = parse_datetime_safe(payload.get("event_ts"))
    return Signal(**payload)


def run_daily_pipeline(
    settings: Settings | None = None,
    db: Database | None = None,
) -> dict:
    started = perf_counter()
    settings = settings or get_settings()
    db = db or get_database(settings)

    ok, message = db.validate_connection()
    if not ok:
        raise RuntimeError(message or "Database is not available.")

    llm = OpenRouterClient(settings)

    stocks = collect_stock_universe(settings)
    db.upsert_stocks(stocks)
    selected_stock_ids = {row.get("stock_id") for row in stocks if row.get("stock_id")}
    symbol_to_stock_id = {
        str(row.get("symbol") or "").upper(): str(row.get("stock_id"))
        for row in stocks
        if row.get("symbol") and row.get("stock_id")
    }
    selected_symbols = set(symbol_to_stock_id.keys())

    raw_events = collect_raw_events(settings)
    for event in raw_events:
        symbol = str(event.stock_symbol or "").upper()
        preferred_stock_id = symbol_to_stock_id.get(symbol)
        if preferred_stock_id:
            event.stock_id = preferred_stock_id
            event.stock_symbol = symbol

    if selected_symbols:
        raw_events = [event for event in raw_events if str(event.stock_symbol or "").upper() in selected_symbols]
    db.insert_raw_events(raw_events)

    structured_events = normalize_events(raw_events, llm)
    db.insert_structured_events(structured_events)

    fresh_signals = generate_signals(structured_events)
    db.insert_signals(fresh_signals)

    all_stocks_full = stocks if settings.use_curated_universe else db.fetch_stocks()

    if settings.fast_mode:
        active_ids = {
            event.stock_id
            for event in raw_events
            if event.stock_id
        }
        active_ids.update(signal.stock_id for signal in fresh_signals)

        active = [row for row in all_stocks_full if row.get("stock_id") in active_ids]
        inactive = [row for row in all_stocks_full if row.get("stock_id") not in active_ids]

        keep = max(settings.max_stock_universe - len(active), 0)
        all_stocks = active + inactive[:keep]
    else:
        all_stocks = all_stocks_full
    signal_rows = db.fetch_recent_signals(settings.signal_lookback_days)
    signal_history = [_coerce_signal(row) for row in signal_rows]
    if selected_stock_ids:
        signal_history = [signal for signal in signal_history if signal.stock_id in selected_stock_ids]

    run_date = utc_now()
    scores = rank_stocks(all_stocks, signal_history, run_date)

    by_stock: dict[str, list[Signal]] = {}
    for signal in signal_history:
        by_stock.setdefault(signal.stock_id, []).append(signal)

    for score in scores:
        score_signals = by_stock.get(score.stock_id, [])
        score.explanation = generate_stock_explanation(score, score_signals, llm)

    db.upsert_scores(scores)

    alerts = generate_alerts(
        scores=scores,
        threshold=settings.alert_score_threshold,
        top_n=settings.top_alert_count,
    )
    db.insert_alerts(alerts)

    score_rows = [score.model_dump(mode="json") for score in scores]
    try:
        notification_summary = push_watchlist_updates_for_all_users(
            db=db,
            settings=settings,
            run_date=run_date.isoformat(),
            score_rows=score_rows,
        )
    except RuntimeError as error:
        notification_summary = {
            "attempted": 0,
            "sent": 0,
            "failed": 0,
            "skipped": 0,
            "error": str(error),
        }

    return {
        "backend": getattr(db, "backend_name", "unknown"),
        "mode": "fast" if settings.fast_mode else "full",
        "runtime_seconds": round(perf_counter() - started, 2),
        "run_date": run_date.isoformat(),
        "stock_count": len(all_stocks),
        "raw_event_count": len(raw_events),
        "structured_event_count": len(structured_events),
        "signal_count": len(signal_history),
        "alert_count": len(alerts),
        "telegram_notifications": notification_summary,
        "top_5": [
            {
                "rank": score.rank,
                "stock_id": score.stock_id,
                "score": score.final_score,
                "explanation": score.explanation,
            }
            for score in scores[:5]
        ],
    }
