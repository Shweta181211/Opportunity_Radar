from __future__ import annotations

import json
import sqlite3
from datetime import timedelta
from pathlib import Path
from typing import Any

from opportunity_radar.config import Settings
from opportunity_radar.models import RawEvent, ScoreResult, Signal, StructuredEvent
from opportunity_radar.utils import utc_now


class LocalDatabase:
    def __init__(self, settings: Settings, fallback_reason: str | None = None):
        self.settings = settings
        self.backend_name = "sqlite"
        self.fallback_reason = fallback_reason
        db_path = Path(settings.local_db_path)
        if not db_path.is_absolute():
            db_path = Path.cwd() / db_path
        self.db_path = db_path
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def is_configured(self) -> bool:
        return True

    def validate_connection(self) -> tuple[bool, str | None]:
        return True, None

    def _init_schema(self) -> None:
        self.conn.executescript(
            """
            create table if not exists stocks (
                stock_id text primary key,
                symbol text not null,
                exchange text not null,
                name text,
                isin text,
                created_at text not null,
                updated_at text not null
            );

            create unique index if not exists idx_stocks_exchange_symbol on stocks(exchange, symbol);

            create table if not exists raw_events (
                id integer primary key autoincrement,
                source text not null,
                source_event_id text not null,
                stock_id text,
                stock_symbol text,
                published_at text not null,
                title text,
                text text,
                payload text not null default '{}',
                ingested_at text not null,
                unique(source, source_event_id)
            );

            create index if not exists idx_raw_events_stock_id on raw_events(stock_id);
            create index if not exists idx_raw_events_published_at on raw_events(published_at desc);

            create table if not exists structured_events (
                id integer primary key autoincrement,
                source text not null,
                source_event_id text not null,
                stock_id text not null,
                stock_symbol text not null,
                event_type text not null,
                magnitude real not null default 0,
                sentiment text not null,
                confidence real not null default 0.5,
                timestamp text not null,
                raw_text text,
                created_at text not null,
                unique(source, source_event_id)
            );

            create index if not exists idx_structured_events_stock_id on structured_events(stock_id);
            create index if not exists idx_structured_events_timestamp on structured_events(timestamp desc);

            create table if not exists signals (
                id integer primary key autoincrement,
                stock_id text not null,
                stock_symbol text not null,
                signal_type text not null,
                category text not null,
                strength real not null,
                confidence real not null,
                explanation text not null,
                event_ts text not null,
                magnitude real not null default 0,
                created_at text not null,
                unique(stock_id, signal_type, event_ts)
            );

            create index if not exists idx_signals_stock_id on signals(stock_id);
            create index if not exists idx_signals_event_ts on signals(event_ts desc);

            create table if not exists scores (
                id integer primary key autoincrement,
                run_date text not null,
                stock_id text not null,
                stock_symbol text not null,
                insider_score real not null,
                earnings_score real not null,
                sentiment_score real not null,
                event_score real not null,
                raw_score real not null,
                density_bonus real not null,
                confidence_multiplier real not null,
                recency_multiplier real not null,
                final_score real not null,
                rank integer not null,
                explanation text not null,
                created_at text not null,
                unique(run_date, stock_id)
            );

            create index if not exists idx_scores_run_date on scores(run_date desc);
            create index if not exists idx_scores_rank on scores(run_date desc, rank asc);

            create table if not exists alerts (
                id integer primary key autoincrement,
                run_date text not null,
                stock_id text not null,
                stock_symbol text not null,
                alert_type text not null,
                message text not null,
                created_at text not null,
                unique(run_date, stock_id)
            );

            create index if not exists idx_alerts_run_date on alerts(run_date desc);

            create table if not exists users (
                user_id text primary key,
                display_name text not null,
                telegram_chat_id text,
                created_at text not null,
                updated_at text not null
            );

            create table if not exists user_watchlists (
                id integer primary key autoincrement,
                user_id text not null,
                stock_symbol text not null,
                created_at text not null,
                unique(user_id, stock_symbol)
            );

            create index if not exists idx_user_watchlists_user_id on user_watchlists(user_id);

            create table if not exists user_notification_logs (
                id integer primary key autoincrement,
                user_id text not null,
                run_date text not null,
                channel text not null,
                status text not null,
                message text not null,
                created_at text not null,
                unique(user_id, run_date, channel)
            );
            """
        )
        self.conn.commit()

    @staticmethod
    def _rows_to_dicts(rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
        data: list[dict[str, Any]] = []
        for row in rows:
            payload = dict(row)
            if "payload" in payload and isinstance(payload["payload"], str):
                try:
                    payload["payload"] = json.loads(payload["payload"])
                except json.JSONDecodeError:
                    pass
            data.append(payload)
        return data

    def upsert_stocks(self, rows: list[dict[str, Any]]) -> int:
        if not rows:
            return 0
        now = utc_now().isoformat()
        payload = [
            {
                "stock_id": row.get("stock_id"),
                "symbol": row.get("symbol", ""),
                "exchange": row.get("exchange", ""),
                "name": row.get("name"),
                "isin": row.get("isin"),
                "created_at": now,
                "updated_at": now,
            }
            for row in rows
            if row.get("stock_id")
        ]
        self.conn.executemany(
            """
            insert into stocks(stock_id, symbol, exchange, name, isin, created_at, updated_at)
            values(:stock_id, :symbol, :exchange, :name, :isin, :created_at, :updated_at)
            on conflict(stock_id) do update set
              symbol=excluded.symbol,
              exchange=excluded.exchange,
              name=excluded.name,
              isin=excluded.isin,
              updated_at=excluded.updated_at
            """,
            payload,
        )
        self.conn.commit()
        return len(payload)

    def insert_raw_events(self, events: list[RawEvent]) -> int:
        if not events:
            return 0
        now = utc_now().isoformat()
        rows = []
        for event in events:
            rows.append(
                {
                    "source": event.source,
                    "source_event_id": event.source_event_id,
                    "stock_id": event.stock_id,
                    "stock_symbol": event.stock_symbol,
                    "published_at": event.published_at.isoformat(),
                    "title": event.title,
                    "text": event.text,
                    "payload": json.dumps(event.payload, default=str),
                    "ingested_at": now,
                }
            )
        self.conn.executemany(
            """
            insert into raw_events(
              source, source_event_id, stock_id, stock_symbol, published_at, title, text, payload, ingested_at
            )
            values(
              :source, :source_event_id, :stock_id, :stock_symbol, :published_at, :title, :text, :payload, :ingested_at
            )
            on conflict(source, source_event_id) do update set
              stock_id=excluded.stock_id,
              stock_symbol=excluded.stock_symbol,
              published_at=excluded.published_at,
              title=excluded.title,
              text=excluded.text,
              payload=excluded.payload
            """,
            rows,
        )
        self.conn.commit()
        return len(rows)

    def insert_structured_events(self, events: list[StructuredEvent]) -> int:
        if not events:
            return 0
        now = utc_now().isoformat()
        rows = []
        for event in events:
            rows.append(
                {
                    "source": event.source,
                    "source_event_id": event.source_event_id,
                    "stock_id": event.stock_id,
                    "stock_symbol": event.stock_symbol,
                    "event_type": event.event_type,
                    "magnitude": event.magnitude,
                    "sentiment": event.sentiment,
                    "confidence": event.confidence,
                    "timestamp": event.timestamp.isoformat(),
                    "raw_text": event.raw_text,
                    "created_at": now,
                }
            )
        self.conn.executemany(
            """
            insert into structured_events(
              source, source_event_id, stock_id, stock_symbol, event_type, magnitude,
              sentiment, confidence, timestamp, raw_text, created_at
            )
            values(
              :source, :source_event_id, :stock_id, :stock_symbol, :event_type, :magnitude,
              :sentiment, :confidence, :timestamp, :raw_text, :created_at
            )
            on conflict(source, source_event_id) do update set
              stock_id=excluded.stock_id,
              stock_symbol=excluded.stock_symbol,
              event_type=excluded.event_type,
              magnitude=excluded.magnitude,
              sentiment=excluded.sentiment,
              confidence=excluded.confidence,
              timestamp=excluded.timestamp,
              raw_text=excluded.raw_text
            """,
            rows,
        )
        self.conn.commit()
        return len(rows)

    def insert_signals(self, signals: list[Signal]) -> int:
        if not signals:
            return 0
        now = utc_now().isoformat()
        rows = []
        for signal in signals:
            rows.append(
                {
                    "stock_id": signal.stock_id,
                    "stock_symbol": signal.stock_symbol,
                    "signal_type": signal.signal_type,
                    "category": signal.category,
                    "strength": signal.strength,
                    "confidence": signal.confidence,
                    "explanation": signal.explanation,
                    "event_ts": signal.event_ts.isoformat(),
                    "magnitude": signal.magnitude,
                    "created_at": now,
                }
            )
        self.conn.executemany(
            """
            insert into signals(
              stock_id, stock_symbol, signal_type, category, strength,
              confidence, explanation, event_ts, magnitude, created_at
            )
            values(
              :stock_id, :stock_symbol, :signal_type, :category, :strength,
              :confidence, :explanation, :event_ts, :magnitude, :created_at
            )
            on conflict(stock_id, signal_type, event_ts) do update set
              stock_symbol=excluded.stock_symbol,
              category=excluded.category,
              strength=excluded.strength,
              confidence=excluded.confidence,
              explanation=excluded.explanation,
              magnitude=excluded.magnitude
            """,
            rows,
        )
        self.conn.commit()
        return len(rows)

    def upsert_scores(self, scores: list[ScoreResult]) -> int:
        if not scores:
            return 0
        now = utc_now().isoformat()
        rows = []
        for score in scores:
            rows.append(
                {
                    "run_date": score.run_date.isoformat(),
                    "stock_id": score.stock_id,
                    "stock_symbol": score.stock_symbol,
                    "insider_score": score.insider_score,
                    "earnings_score": score.earnings_score,
                    "sentiment_score": score.sentiment_score,
                    "event_score": score.event_score,
                    "raw_score": score.raw_score,
                    "density_bonus": score.density_bonus,
                    "confidence_multiplier": score.confidence_multiplier,
                    "recency_multiplier": score.recency_multiplier,
                    "final_score": score.final_score,
                    "rank": score.rank,
                    "explanation": score.explanation,
                    "created_at": now,
                }
            )
        self.conn.executemany(
            """
            insert into scores(
              run_date, stock_id, stock_symbol, insider_score, earnings_score,
              sentiment_score, event_score, raw_score, density_bonus,
              confidence_multiplier, recency_multiplier, final_score,
              rank, explanation, created_at
            )
            values(
              :run_date, :stock_id, :stock_symbol, :insider_score, :earnings_score,
              :sentiment_score, :event_score, :raw_score, :density_bonus,
              :confidence_multiplier, :recency_multiplier, :final_score,
              :rank, :explanation, :created_at
            )
            on conflict(run_date, stock_id) do update set
              stock_symbol=excluded.stock_symbol,
              insider_score=excluded.insider_score,
              earnings_score=excluded.earnings_score,
              sentiment_score=excluded.sentiment_score,
              event_score=excluded.event_score,
              raw_score=excluded.raw_score,
              density_bonus=excluded.density_bonus,
              confidence_multiplier=excluded.confidence_multiplier,
              recency_multiplier=excluded.recency_multiplier,
              final_score=excluded.final_score,
              rank=excluded.rank,
              explanation=excluded.explanation
            """,
            rows,
        )
        self.conn.commit()
        return len(rows)

    def insert_alerts(self, alerts: list[dict[str, Any]]) -> int:
        if not alerts:
            return 0
        now = utc_now().isoformat()
        rows = []
        for alert in alerts:
            rows.append(
                {
                    "run_date": str(alert.get("run_date", "")),
                    "stock_id": str(alert.get("stock_id", "")),
                    "stock_symbol": str(alert.get("stock_symbol", "")),
                    "alert_type": str(alert.get("alert_type", "TOP_OPPORTUNITY")),
                    "message": str(alert.get("message", "")),
                    "created_at": now,
                }
            )
        self.conn.executemany(
            """
            insert into alerts(run_date, stock_id, stock_symbol, alert_type, message, created_at)
            values(:run_date, :stock_id, :stock_symbol, :alert_type, :message, :created_at)
            on conflict(run_date, stock_id) do update set
              stock_symbol=excluded.stock_symbol,
              alert_type=excluded.alert_type,
              message=excluded.message
            """,
            rows,
        )
        self.conn.commit()
        return len(rows)

    def fetch_stocks(self) -> list[dict[str, Any]]:
        rows = self.conn.execute("select * from stocks order by stock_id asc").fetchall()
        return self._rows_to_dicts(rows)

    def fetch_recent_raw_events(
        self, limit: int = 200, source: str | None = None, stock_id: str | None = None
    ) -> list[dict[str, Any]]:
        sql = "select * from raw_events where 1=1"
        params: list[Any] = []
        if source:
            sql += " and source = ?"
            params.append(source)
        if stock_id:
            sql += " and stock_id = ?"
            params.append(stock_id)
        sql += " order by published_at desc limit ?"
        params.append(limit)
        rows = self.conn.execute(sql, params).fetchall()
        return self._rows_to_dicts(rows)

    def fetch_recent_signals(self, days: int) -> list[dict[str, Any]]:
        cutoff = (utc_now() - timedelta(days=days)).isoformat()
        rows = self.conn.execute(
            "select * from signals where event_ts >= ? order by event_ts desc",
            (cutoff,),
        ).fetchall()
        return self._rows_to_dicts(rows)

    def fetch_latest_scores(self, limit: int = 500) -> list[dict[str, Any]]:
        latest = self.conn.execute("select max(run_date) as run_date from scores").fetchone()
        if not latest or not latest["run_date"]:
            return []
        rows = self.conn.execute(
            "select * from scores where run_date = ? order by rank asc limit ?",
            (latest["run_date"], limit),
        ).fetchall()
        return self._rows_to_dicts(rows)

    def fetch_stock_detail(self, stock_id: str) -> dict[str, Any]:
        score = self.conn.execute(
            "select * from scores where stock_id = ? order by run_date desc limit 1",
            (stock_id,),
        ).fetchone()
        signals = self.conn.execute(
            "select * from signals where stock_id = ? order by event_ts desc limit 30",
            (stock_id,),
        ).fetchall()
        events = self.conn.execute(
            "select * from structured_events where stock_id = ? order by timestamp desc limit 30",
            (stock_id,),
        ).fetchall()
        return {
            "score": dict(score) if score else None,
            "signals": self._rows_to_dicts(signals),
            "events": self._rows_to_dicts(events),
        }

    def fetch_latest_alerts(self, limit: int = 30) -> list[dict[str, Any]]:
        latest = self.conn.execute("select max(run_date) as run_date from alerts").fetchone()
        if not latest or not latest["run_date"]:
            return []
        rows = self.conn.execute(
            "select * from alerts where run_date = ? order by created_at desc limit ?",
            (latest["run_date"], limit),
        ).fetchall()
        return self._rows_to_dicts(rows)

    def upsert_user_profile(
        self,
        user_id: str,
        display_name: str,
        telegram_chat_id: str | None = None,
    ) -> dict[str, Any]:
        now = utc_now().isoformat()
        self.conn.execute(
            """
            insert into users(user_id, display_name, telegram_chat_id, created_at, updated_at)
            values(?, ?, ?, ?, ?)
            on conflict(user_id) do update set
              display_name=excluded.display_name,
              telegram_chat_id=excluded.telegram_chat_id,
              updated_at=excluded.updated_at
            """,
            (user_id, display_name, telegram_chat_id or None, now, now),
        )
        self.conn.commit()
        profile = self.fetch_user_profile(user_id)
        return profile or {
            "user_id": user_id,
            "display_name": display_name,
            "telegram_chat_id": telegram_chat_id,
            "created_at": now,
            "updated_at": now,
        }

    def fetch_user_profile(self, user_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "select * from users where user_id = ? limit 1",
            (user_id,),
        ).fetchone()
        if not row:
            return None
        return dict(row)

    def add_user_watchlist_symbols(self, user_id: str, symbols: list[str]) -> int:
        clean_symbols = sorted({str(symbol or "").strip().upper() for symbol in symbols if str(symbol or "").strip()})
        if not clean_symbols:
            return 0
        now = utc_now().isoformat()
        self.conn.executemany(
            """
            insert into user_watchlists(user_id, stock_symbol, created_at)
            values(?, ?, ?)
            on conflict(user_id, stock_symbol) do nothing
            """,
            [(user_id, symbol, now) for symbol in clean_symbols],
        )
        self.conn.commit()
        return len(clean_symbols)

    def fetch_user_watchlist_symbols(self, user_id: str) -> list[str]:
        rows = self.conn.execute(
            "select stock_symbol from user_watchlists where user_id = ? order by stock_symbol asc",
            (user_id,),
        ).fetchall()
        return [str(row["stock_symbol"]).upper() for row in rows if row["stock_symbol"]]

    def remove_user_watchlist_symbol(self, user_id: str, stock_symbol: str) -> None:
        self.conn.execute(
            "delete from user_watchlists where user_id = ? and stock_symbol = ?",
            (user_id, stock_symbol.upper()),
        )
        self.conn.commit()

    def clear_user_watchlist(self, user_id: str) -> None:
        self.conn.execute("delete from user_watchlists where user_id = ?", (user_id,))
        self.conn.commit()

    def fetch_watchlist_subscribers(self) -> list[dict[str, Any]]:
        users = self.conn.execute(
            "select user_id, display_name, telegram_chat_id from users"
        ).fetchall()
        watchlist = self.conn.execute(
            "select user_id, stock_symbol from user_watchlists"
        ).fetchall()

        symbols_by_user: dict[str, list[str]] = {}
        for row in watchlist:
            uid = str(row["user_id"] or "")
            symbol = str(row["stock_symbol"] or "").strip().upper()
            if not uid or not symbol:
                continue
            symbols_by_user.setdefault(uid, []).append(symbol)

        subscribers: list[dict[str, Any]] = []
        for row in users:
            uid = str(row["user_id"] or "")
            chat_id = str(row["telegram_chat_id"] or "").strip()
            symbols = sorted(set(symbols_by_user.get(uid, [])))
            if not uid or not chat_id or not symbols:
                continue
            subscribers.append(
                {
                    "user_id": uid,
                    "display_name": str(row["display_name"] or uid),
                    "telegram_chat_id": chat_id,
                    "symbols": symbols,
                }
            )
        return subscribers

    def log_user_notification(
        self,
        user_id: str,
        run_date: str,
        channel: str,
        status: str,
        message: str,
    ) -> None:
        now = utc_now().isoformat()
        self.conn.execute(
            """
            insert into user_notification_logs(user_id, run_date, channel, status, message, created_at)
            values(?, ?, ?, ?, ?, ?)
            on conflict(user_id, run_date, channel) do update set
              status=excluded.status,
              message=excluded.message,
              created_at=excluded.created_at
            """,
            (user_id, run_date, channel, status, message, now),
        )
        self.conn.commit()
