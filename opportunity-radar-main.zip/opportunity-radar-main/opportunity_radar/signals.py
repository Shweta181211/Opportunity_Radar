from __future__ import annotations

from typing import Iterable

from opportunity_radar.models import Signal, StructuredEvent


def _insider_strength(event: StructuredEvent) -> float:
    magnitude = abs(event.magnitude)
    if event.event_type == "INSIDER_BUY":
        return 25.0 if magnitude >= 1.0 else 15.0
    if event.event_type == "INSIDER_SELL":
        return -25.0 if magnitude >= 1.0 else -15.0
    return 0.0


def _earnings_strength(event: StructuredEvent) -> float:
    if event.event_type == "EARNINGS_BEAT":
        return 20.0
    if event.event_type == "GUIDANCE_UPGRADE":
        return 15.0
    if event.event_type == "EARNINGS_MISS":
        return -20.0
    if event.event_type == "GUIDANCE_DOWNGRADE":
        return -15.0
    return 0.0


def _sentiment_strength(event: StructuredEvent) -> float:
    if event.event_type != "MANAGEMENT_SENTIMENT_SHIFT":
        return 0.0

    magnitude = abs(event.magnitude)
    if event.sentiment == "positive":
        return 15.0 if magnitude >= 1.5 else 5.0
    if event.sentiment == "negative":
        return -15.0
    return 0.0


def _event_strength(event: StructuredEvent) -> float:
    if event.event_type == "REGULATORY_EVENT":
        if event.sentiment == "positive":
            return 20.0
        if event.sentiment == "negative":
            return -20.0
        return 0.0

    if event.event_type == "BULK_DEAL":
        if event.sentiment == "positive":
            return 12.0
        if event.sentiment == "negative":
            return -12.0
    return 0.0


def signal_from_event(event: StructuredEvent) -> Signal | None:
    for category, scorer in (
        ("insider", _insider_strength),
        ("earnings", _earnings_strength),
        ("sentiment", _sentiment_strength),
        ("event", _event_strength),
    ):
        strength = scorer(event)
        if strength == 0:
            continue
        return Signal(
            stock_id=event.stock_id,
            stock_symbol=event.stock_symbol,
            signal_type=event.event_type,
            category=category,
            strength=strength,
            confidence=event.confidence,
            explanation=(
                f"{event.event_type} mapped to {category} signal with strength {strength:+.0f}"
            ),
            event_ts=event.timestamp,
            magnitude=event.magnitude,
        )
    return None


def generate_signals(events: Iterable[StructuredEvent]) -> list[Signal]:
    signals: list[Signal] = []
    for event in events:
        signal = signal_from_event(event)
        if signal:
            signals.append(signal)
    return signals
