from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator


EVENT_TYPES = {
    "INSIDER_BUY",
    "INSIDER_SELL",
    "BULK_DEAL",
    "EARNINGS_BEAT",
    "EARNINGS_MISS",
    "GUIDANCE_UPGRADE",
    "GUIDANCE_DOWNGRADE",
    "MANAGEMENT_SENTIMENT_SHIFT",
    "REGULATORY_EVENT",
}

SENTIMENTS = {"positive", "neutral", "negative"}


class RawEvent(BaseModel):
    source: str
    source_event_id: str
    stock_id: str | None = None
    stock_symbol: str | None = None
    published_at: datetime
    title: str = ""
    text: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)


class StructuredEvent(BaseModel):
    source: str
    source_event_id: str
    stock_id: str
    stock_symbol: str
    event_type: str
    magnitude: float = 0.0
    sentiment: str
    confidence: float = 0.5
    timestamp: datetime
    raw_text: str

    @field_validator("event_type")
    @classmethod
    def validate_event_type(cls, value: str) -> str:
        if value not in EVENT_TYPES:
            raise ValueError(f"Invalid event_type: {value}")
        return value

    @field_validator("sentiment")
    @classmethod
    def validate_sentiment(cls, value: str) -> str:
        if value not in SENTIMENTS:
            raise ValueError(f"Invalid sentiment: {value}")
        return value


class Signal(BaseModel):
    stock_id: str
    stock_symbol: str
    signal_type: str
    category: Literal["insider", "earnings", "sentiment", "event"]
    strength: float
    confidence: float
    explanation: str
    event_ts: datetime
    magnitude: float = 0.0


class ScoreResult(BaseModel):
    run_date: datetime
    stock_id: str
    stock_symbol: str
    insider_score: float
    earnings_score: float
    sentiment_score: float
    event_score: float
    raw_score: float
    density_bonus: float
    confidence_multiplier: float
    recency_multiplier: float
    final_score: float
    rank: int = 0
    explanation: str = ""
