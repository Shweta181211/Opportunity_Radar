from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from typing import Any


PERCENT_PATTERN = re.compile(r"([-+]?\d+(?:\.\d+)?)\s*%")
NUMBER_PATTERN = re.compile(r"([-+]?\d+(?:\.\d+)?)")


def utc_now() -> datetime:
    return datetime.now(tz=timezone.utc)


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def make_stock_id(exchange: str, symbol: str) -> str:
    normalized_exchange = (exchange or "UNK").strip().upper()
    normalized_symbol = (symbol or "").strip().upper().replace(" ", "")
    return f"{normalized_exchange}:{normalized_symbol}"


def parse_datetime_safe(value: Any, fallback: datetime | None = None) -> datetime:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)

    if isinstance(value, str) and value.strip():
        raw = value.strip().replace("Z", "+00:00")
        for fmt in (
            "%Y-%m-%d",
            "%Y-%m-%d %H:%M:%S",
            "%d-%m-%Y",
            "%d/%m/%Y",
            "%d-%b-%Y",
        ):
            try:
                parsed = datetime.strptime(raw, fmt)
                return parsed.replace(tzinfo=timezone.utc)
            except ValueError:
                continue
        try:
            parsed = datetime.fromisoformat(raw)
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            pass

    return fallback or utc_now()


def extract_magnitude(text: str) -> float:
    if not text:
        return 0.0

    percent_match = PERCENT_PATTERN.search(text)
    if percent_match:
        return float(percent_match.group(1))

    values = [float(value) for value in NUMBER_PATTERN.findall(text)]
    if not values:
        return 0.0

    # Pick the largest absolute value as event magnitude proxy.
    return max(values, key=lambda x: abs(x))


def stable_event_id(prefix: str, payload: dict[str, Any]) -> str:
    content = json.dumps(payload, sort_keys=True, default=str)
    digest = hashlib.sha1(content.encode("utf-8")).hexdigest()
    return f"{prefix}_{digest}"
