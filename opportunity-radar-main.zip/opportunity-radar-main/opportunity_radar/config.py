from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache

from dotenv import load_dotenv


load_dotenv(override=True)


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    supabase_url: str = os.getenv("SUPABASE_URL", "")
    supabase_key: str = os.getenv("SUPABASE_KEY", "")

    openrouter_api_key: str = os.getenv("OPENROUTER_API_KEY", "")
    openrouter_model: str = os.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini")
    openrouter_api_url: str = os.getenv("OPENROUTER_API_URL", "https://openrouter.ai/api/v1")

    nse_equity_list_url: str = os.getenv(
        "NSE_EQUITY_LIST_URL",
        "https://archives.nseindia.com/content/equities/EQUITY_L.csv",
    )
    bse_equity_list_url: str = os.getenv(
        "BSE_EQUITY_LIST_URL",
        "https://api.bseindia.com/BseIndiaAPI/api/ListofScripData/w",
    )
    nse_bulk_deals_url: str = os.getenv(
        "NSE_BULK_DEALS_URL", "https://www.nseindia.com/api/historicalOR/bulk-block-short-deals"
    )
    bse_announcements_url: str = os.getenv(
        "BSE_ANNOUNCEMENTS_URL",
        "https://api.bseindia.com/BseIndiaAPI/api/AnnSubCategoryGetData/w",
    )
    sebi_insider_url: str = os.getenv(
        "SEBI_INSIDER_URL", "https://www.nseindia.com/api/corporates-pit"
    )

    request_timeout_seconds: int = int(os.getenv("REQUEST_TIMEOUT_SECONDS", "30"))
    signal_lookback_days: int = int(os.getenv("SIGNAL_LOOKBACK_DAYS", "14"))
    top_alert_count: int = int(os.getenv("TOP_ALERT_COUNT", "20"))
    alert_score_threshold: float = float(os.getenv("ALERT_SCORE_THRESHOLD", "68"))

    scheduler_hour_ist: int = int(os.getenv("SCHEDULER_HOUR_IST", "18"))
    scheduler_minute_ist: int = int(os.getenv("SCHEDULER_MINUTE_IST", "5"))

    allow_local_db_fallback: bool = _env_bool("ALLOW_LOCAL_DB_FALLBACK", True)
    local_db_path: str = os.getenv("LOCAL_DB_PATH", "opportunity_radar_local.db")

    fast_mode: bool = _env_bool("FAST_MODE", True)
    use_curated_universe: bool = _env_bool("USE_CURATED_UNIVERSE", True)
    max_stock_universe: int = int(os.getenv("MAX_STOCK_UNIVERSE", "100"))
    max_events_per_source: int = int(os.getenv("MAX_EVENTS_PER_SOURCE", "250"))
    max_total_events: int = int(os.getenv("MAX_TOTAL_EVENTS", "600"))
    disable_openrouter_in_fast_mode: bool = _env_bool("DISABLE_OPENROUTER_IN_FAST_MODE", True)

    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_api_url: str = os.getenv("TELEGRAM_API_URL", "https://api.telegram.org")
    telegram_updates_enabled: bool = _env_bool("TELEGRAM_UPDATES_ENABLED", True)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
