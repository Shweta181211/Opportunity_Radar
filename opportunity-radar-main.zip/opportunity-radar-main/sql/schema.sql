create extension if not exists pgcrypto;

create table if not exists stocks (
    stock_id text primary key,
    symbol text not null,
    exchange text not null,
    name text,
    isin text,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create unique index if not exists idx_stocks_exchange_symbol on stocks(exchange, symbol);

create table if not exists raw_events (
    id uuid primary key default gen_random_uuid(),
    source text not null,
    source_event_id text not null,
    stock_id text,
    stock_symbol text,
    published_at timestamptz not null,
    title text,
    text text,
    payload jsonb not null default '{}'::jsonb,
    ingested_at timestamptz not null default now(),
    unique(source, source_event_id)
);

create index if not exists idx_raw_events_stock_id on raw_events(stock_id);
create index if not exists idx_raw_events_published_at on raw_events(published_at desc);

create table if not exists structured_events (
    id uuid primary key default gen_random_uuid(),
    source text not null,
    source_event_id text not null,
    stock_id text not null,
    stock_symbol text not null,
    event_type text not null,
    magnitude double precision not null default 0,
    sentiment text not null,
    confidence double precision not null default 0.5,
    timestamp timestamptz not null,
    raw_text text,
    created_at timestamptz not null default now(),
    unique(source, source_event_id)
);

create index if not exists idx_structured_events_stock_id on structured_events(stock_id);
create index if not exists idx_structured_events_timestamp on structured_events(timestamp desc);

create table if not exists signals (
    id uuid primary key default gen_random_uuid(),
    stock_id text not null,
    stock_symbol text not null,
    signal_type text not null,
    category text not null,
    strength double precision not null,
    confidence double precision not null,
    explanation text not null,
    event_ts timestamptz not null,
    magnitude double precision not null default 0,
    created_at timestamptz not null default now(),
    unique(stock_id, signal_type, event_ts)
);

create index if not exists idx_signals_stock_id on signals(stock_id);
create index if not exists idx_signals_event_ts on signals(event_ts desc);

create table if not exists scores (
    id uuid primary key default gen_random_uuid(),
    run_date timestamptz not null,
    stock_id text not null,
    stock_symbol text not null,
    insider_score double precision not null,
    earnings_score double precision not null,
    sentiment_score double precision not null,
    event_score double precision not null,
    raw_score double precision not null,
    density_bonus double precision not null,
    confidence_multiplier double precision not null,
    recency_multiplier double precision not null,
    final_score double precision not null,
    rank integer not null,
    explanation text not null,
    created_at timestamptz not null default now(),
    unique(run_date, stock_id)
);

create index if not exists idx_scores_run_date on scores(run_date desc);
create index if not exists idx_scores_rank on scores(run_date desc, rank asc);

create table if not exists alerts (
    id uuid primary key default gen_random_uuid(),
    run_date timestamptz not null,
    stock_id text not null,
    stock_symbol text not null,
    alert_type text not null,
    message text not null,
    created_at timestamptz not null default now(),
    unique(run_date, stock_id)
);

create index if not exists idx_alerts_run_date on alerts(run_date desc);

create table if not exists users (
    user_id text primary key,
    display_name text not null,
    telegram_chat_id text,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists user_watchlists (
    id uuid primary key default gen_random_uuid(),
    user_id text not null references users(user_id) on delete cascade,
    stock_symbol text not null,
    created_at timestamptz not null default now(),
    unique(user_id, stock_symbol)
);

create index if not exists idx_user_watchlists_user_id on user_watchlists(user_id);
create index if not exists idx_user_watchlists_symbol on user_watchlists(stock_symbol);

create table if not exists user_notification_logs (
    id uuid primary key default gen_random_uuid(),
    user_id text not null references users(user_id) on delete cascade,
    run_date timestamptz not null,
    channel text not null,
    status text not null,
    message text not null,
    created_at timestamptz not null default now(),
    unique(user_id, run_date, channel)
);

create index if not exists idx_user_notification_logs_user_id on user_notification_logs(user_id);
